<template>
  <div style="width:1600px; margin:0 auto; display:block; position:relative; bottom:200px;">
    <div class="main-box03">
      <h2 class="main-tit main-motion">
        <span>BRAND STORY</span>
      </h2>
      <div class="inner">
        <div class="bn-wrap main-motion" style="max-width:1000px; margin:0 auto;">
          <a href="#none"><img src="/img/main_mid_bn.png" alt="banner"/></a>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
export default {
 components: {
   }
 };
</script>
<style>
.main-tit{position:relative;color:#2b2b2b;text-align:center;line-height:1.2;}
.main-tit strong{display:block;padding:30px 0 20px;font-size:32px;}
.main-tit span{ display:block;padding:20px 0 55px;font-size:30px;color:#fff;font-weight:300;letter-spacing:3px;}
.main-tit span:before{ content:'';position:absolute;top:0;left:50%;display:block;width:38px;height:2px;margin-left:-19px;background:#fff;}
.main-tit a{position:absolute;top:40px;right:0;padding-right:15px;background:url('/img/main_more.png') no-repeat right center;font-size:18px;font-weight:300;color:#888888;}
.main-box03{width:100%;height:420px;padding-top:80px;margin:0 auto 220px;background:url("/img/main_fixed_bg.jpg") center top no-repeat;background-attachment:fixed;box-sizing:border-box;}
.main-box03 .bn-wrap{overflow:hidden;background:#fff;border-radius:26px;box-shadow:9px 8px 20px 8px rgba(0,0,0,0.1);}
.main-motion {position:relative;top:40px;opacity:1;}
div.ec-base-help ol .item10{background-position:-34px -900px;}
div.ec-base-help ul li{padding:0 0 0 11px;background:url('//img.echosting.cafe24.com/skin/base/common/ico_dash.gif') no-repeat 0 7px;}


</style>
